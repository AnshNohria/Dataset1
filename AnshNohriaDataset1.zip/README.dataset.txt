# project1 > 2024-06-18 8:06am
https://universe.roboflow.com/ghost-e3yix/project1-o5f48

Provided by a Roboflow user
License: CC BY 4.0

